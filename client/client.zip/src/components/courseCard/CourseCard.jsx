import { useNavigate } from "react-router-dom";
import * as svgs from "@assets";
import styles from "./CourseCard.module.css";
import PropTypes from "prop-types";


function CourseCard(props) {
  const navigate = useNavigate();
  
  return (
    <div className={styles.courseCard}>
      <div className={styles.courseCardUpper}>
        {props.course.name}
      </div>
      <div className={styles.courseCardLower}>
        <div className={styles.actions}>
          <div className={styles.actionItem} onClick={navigate("/announcements")}>
            <img src={svgs.Announcement}></img>
          </div>
          <div className={styles.actionItem} onClick={navigate("/assignments")}>
            <img src={svgs.Assignment}></img>
          </div>
          <div className={styles.actionItem} onClick={navigate("/files")}>
            <img src={svgs.Files}></img>
          </div>
        </div>
      </div>
    </div>
  );
}

CourseCard.propTypes = {
  course: PropTypes.object.isRequired,
};

export default CourseCard;
